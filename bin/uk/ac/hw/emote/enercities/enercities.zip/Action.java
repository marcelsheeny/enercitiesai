package uk.ac.hw.emote.enercities;

public class Action {
	private String bestActionIdentified;
	private int action;
	private int subaction;
	private String posx;
	private String posy;
	
	private int action2;
	private int action3;
	private int subaction2;
	private int subaction3;
	private String posx2;
	private String posy2;
	private String posx3;
	private String posy3;
	
	
	public String getBestActionIdentified() {
		return bestActionIdentified;
	}
	public void setBestActionIdentified(String bestActionIdentified) {
		this.bestActionIdentified = bestActionIdentified;
	}
	public int getAction() {
		return action;
	}
	public void setAction(int action) {
		this.action = action;
	}
	public int getSubaction() {
		return subaction;
	}
	public void setSubaction(int subaction) {
		this.subaction = subaction;
	}
	public String getPosx() {
		return posx;
	}
	public void setPosx(String posx) {
		this.posx = posx;
	}
	public String getPosy() {
		return posy;
	}
	public void setPosy(String posy) {
		this.posy = posy;
	}
	public int getSubaction2() {
		return subaction2;
	}
	public void setSubaction2(int subaction2) {
		this.subaction2 = subaction2;
	}
	public int getSubaction3() {
		return subaction3;
	}
	public void setSubaction3(int subaction3) {
		this.subaction3 = subaction3;
	}
	public String getPosx2() {
		return posx2;
	}
	public void setPosx2(String posx2) {
		this.posx2 = posx2;
	}
	public String getPosy2() {
		return posy2;
	}
	public void setPosy2(String posy2) {
		this.posy2 = posy2;
	}
	public String getPosx3() {
		return posx3;
	}
	public void setPosx3(String posx3) {
		this.posx3 = posx3;
	}
	public String getPosy3() {
		return posy3;
	}
	public void setPosy3(String posy3) {
		this.posy3 = posy3;
	}
	public int getAction2() {
		return action2;
	}
	public void setAction2(int action2) {
		this.action2 = action2;
	}
	public int getAction3() {
		return action3;
	}
	public void setAction3(int action3) {
		this.action3 = action3;
	}
	
	
	
}
